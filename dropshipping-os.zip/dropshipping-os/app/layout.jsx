export const metadata = {
  title: 'Dropshipping OS — Avatars IA · Organique',
  description: 'Guide complet dropshipping avec avatars IA, sans pub payée',
}

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <body style={{ margin: 0, padding: 0, background: '#F9FAFB' }}>
        {children}
      </body>
    </html>
  )
}
